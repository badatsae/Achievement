package com.personal.achievery;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int SAVE_REQUEST = 901;
    private static final int RESTORE_REQUEST = 902;
    private WebView webView;
    private String pendingBackup;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,16,24));
        getWindow().setNavigationBarColor(Color.rgb(17,24,34));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,16,24));
        setContentView(webView);
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new LocalBridge(), "MoaAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class LocalBridge {
        @JavascriptInterface public void copyText(String content) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("모아 AI 업적 생성 요청문", content));
            });
        }
        @JavascriptInterface public void saveBackup(String json) {
            runOnUiThread(() -> {
                pendingBackup=json;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,"모아_업적_백업.json");
                startActivityForResult(intent,SAVE_REQUEST);
            });
        }
        @JavascriptInterface public void restoreBackup() {
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent,RESTORE_REQUEST);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(requestCode==SAVE_REQUEST && pendingBackup!=null) {
                try(OutputStream out=getContentResolver().openOutputStream(uri)) {
                    if(out==null)throw new Exception("저장 위치를 열지 못했습니다.");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this,"백업을 저장했습니다.",Toast.LENGTH_SHORT).show();
                pendingBackup=null;
            } else if(requestCode==RESTORE_REQUEST) {
                ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                try(InputStream in=getContentResolver().openInputStream(uri)) {
                    if(in==null)throw new Exception("파일을 열지 못했습니다.");
                    byte[] bytes=new byte[4096];int n;
                    while((n=in.read(bytes))!=-1) {
                        if(buffer.size()>2_000_000)throw new Exception("백업 파일이 너무 큽니다.");
                        buffer.write(bytes,0,n);
                    }
                }
                String text=buffer.toString(StandardCharsets.UTF_8.name());
                webView.evaluateJavascript("window.moaRestoreFromAndroid("+JSONObject.quote(text)+")",null);
            }
        } catch(Exception ex) {
            Toast.makeText(this,"파일 처리 오류: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("document.querySelector('#overlay').classList.contains('visible')",val-> {
            if("true".equals(val))webView.evaluateJavascript("document.querySelector('#overlay').click()",null);
            else webView.evaluateJavascript("showTab('home')",null);
        });
    }

    @Override protected void onDestroy() {
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
}
